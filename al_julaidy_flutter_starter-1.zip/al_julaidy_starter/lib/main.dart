import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const appName = 'AL-JULAIDY';
const subtitle = 'ISLAMIC DATING AND MARRIAGE';
const emerald = Color(0xFF104638);
const gold = Color(0xFFC49A45);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Configure Supabase before release. Until then, the app runs in demo mode.
  const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  if (supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    await Supabase.initialize(
      url: supabaseUrl,
      anonKey: supabaseAnonKey,
    );
  }

  runApp(const AlJulaidyApp());
}

class AlJulaidyApp extends StatelessWidget {
  const AlJulaidyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '$appName $subtitle',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: emerald,
          primary: emerald,
          secondary: gold,
          surface: const Color(0xFFFFFCF5),
        ),
        scaffoldBackgroundColor: const Color(0xFFFFFCF5),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedIndex = 0;
  String language = 'English';

  final pages = const [
    HomePage(),
    DiscoverPage(),
    WaliPage(),
    MembershipPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: emerald,
        foregroundColor: Colors.white,
        title: const Text(appName, style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Choose language',
            onSelected: (value) => setState(() => language = value),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'English', child: Text('English')),
              PopupMenuItem(value: 'العربية', child: Text('العربية')),
              PopupMenuItem(value: 'Yorùbá', child: Text('Yorùbá')),
            ],
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Center(child: Text(language)),
            ),
          ),
        ],
      ),
      body: pages[selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (value) => setState(() => selectedIndex = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.favorite_border), label: 'Discover'),
          NavigationDestination(icon: Icon(Icons.people_outline), label: 'Wali'),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), label: 'Premium'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: emerald,
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.nightlight_round, color: gold, size: 34),
              SizedBox(height: 12),
              Text(appName, style: TextStyle(color: gold, fontSize: 27, fontWeight: FontWeight.bold)),
              Text(subtitle, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
              SizedBox(height: 10),
              Text('A Journey Towards Halal Marriage', style: TextStyle(color: gold)),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text('Assalamu Alaikum', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Build a thoughtful profile and discover serious marriage introductions.'),
        const SizedBox(height: 18),
        const FeatureTile(icon: Icons.person_add_alt_1, title: 'Create your profile', detail: 'Registration is for adults aged 18 and above.'),
        const FeatureTile(icon: Icons.verified_user_outlined, title: 'Verify your account', detail: 'Phone and identity verification will be connected securely.'),
        const FeatureTile(icon: Icons.people_outline, title: 'Optional Wali involvement', detail: 'Invite a trusted guardian if you choose.'),
        const FeatureTile(icon: Icons.language, title: 'Worldwide community', detail: 'Arabic, English and Yoruba language support planned.'),
      ],
    );
  }
}

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: const [
        Text('Discover', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('Profiles below are sample placeholders, not real members. Live matchmaking requires verified accounts and moderation.'),
        SizedBox(height: 16),
        SampleProfile(name: 'Sample profile 01', country: 'Country shown after member consent'),
        SampleProfile(name: 'Sample profile 02', country: 'Country shown after member consent'),
      ],
    );
  }
}

class SampleProfile extends StatelessWidget {
  final String name;
  final String country;
  const SampleProfile({super.key, required this.name, required this.country});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFECE4D2), child: Icon(Icons.person, color: emerald)),
        title: Text(name),
        subtitle: Text(country),
        trailing: const Icon(Icons.lock_outline),
      ),
    );
  }
}

class WaliPage extends StatefulWidget {
  const WaliPage({super.key});

  @override
  State<WaliPage> createState() => _WaliPageState();
}

class _WaliPageState extends State<WaliPage> {
  bool wantsWali = false;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('Wali involvement', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Wali participation is optional in this app. You can choose whether to invite a guardian.'),
        const SizedBox(height: 18),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('I want to involve a Wali'),
          subtitle: const Text('You can change this preference later.'),
          value: wantsWali,
          onChanged: (value) => setState(() => wantsWali = value),
        ),
        if (wantsWali)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('The production version will let you send a secure invitation and record the guardian’s consent. No invitation is sent in this starter app.'),
            ),
          ),
      ],
    );
  }
}

class MembershipPage extends StatelessWidget {
  const MembershipPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: const [
        Text('Membership', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        SizedBox(height: 14),
        PlanCard(title: 'Free', price: '₦0', details: 'Account creation, basic profile and core safety features.'),
        PlanCard(title: 'Premium', price: 'Price to be announced', details: 'Optional future extras such as advanced search filters. Core safety features remain available to everyone.'),
      ],
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: const [
        Text('My profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        SizedBox(height: 14),
        FeatureTile(icon: Icons.account_circle_outlined, title: 'Profile details', detail: 'Profile editing will be connected to your secure account.'),
        FeatureTile(icon: Icons.shield_outlined, title: 'Privacy and safety', detail: 'Report, block and account deletion controls are required before launch.'),
        FeatureTile(icon: Icons.translate, title: 'Language', detail: 'English, Arabic and Yoruba translation will be completed before release.'),
      ],
    );
  }
}

class FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String detail;
  const FeatureTile({super.key, required this.icon, required this.title, required this.detail});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: Icon(icon, color: gold, size: 28),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(detail),
      ),
    );
  }
}

class PlanCard extends StatelessWidget {
  final String title;
  final String price;
  final String details;
  const PlanCard({super.key, required this.title, required this.price, required this.details});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text(price, style: const TextStyle(color: emerald, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Text(details),
        ]),
      ),
    );
  }
}
