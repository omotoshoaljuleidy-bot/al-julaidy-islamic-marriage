# AL-JULAIDY Islamic Dating and Marriage — Starter

This is a Flutter starter project for the Android-first AL-JULAIDY app.

## Included
- Emerald and gold visual identity
- Home, Discover, Wali, Membership and Profile screens
- Optional Wali preference control
- English/Arabic/Yoruba language selector placeholder
- Supabase initialization hook
- Initial Supabase profile and Wali-invitation schema

## Important status
This is starter source code, not a production-ready matchmaking service.
It does not yet provide real account registration, OTP delivery, identity checks,
live profiles, chat, payments, moderation, or full translations. Do not publish
it as a functioning dating service until those systems and safeguards are built,
tested, and reviewed.

## Requirements
- Flutter SDK (stable)
- Android Studio or VS Code with Flutter extension
- A Supabase project for backend development

## Run locally
1. Install Flutter and Android Studio.
2. Unzip this project.
3. From the project folder run:
   ```bash
   flutter pub get
   flutter run
   ```
4. To connect Supabase, provide the project URL and anon key:
   ```bash
   flutter run --dart-define=SUPABASE_URL=YOUR_SUPABASE_URL --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
   ```
5. Run `supabase/schema.sql` in the Supabase SQL editor after reviewing it.

Never put a Supabase service-role key in a mobile app. Only use the public anon key
with correctly configured Row Level Security policies.

## Required before launch
- Real authentication and phone OTP provider
- Third-party identity verification provider and secure document handling
- Complete Arabic, English and Yoruba localization including right-to-left layout
- Mutual-consent matching and safe messaging
- Block/report, moderation and appeals workflows
- Account deletion and privacy/data-retention controls
- Subscription/payment integration and store billing compliance
- Security review, legal/privacy review, accessibility testing and store testing
