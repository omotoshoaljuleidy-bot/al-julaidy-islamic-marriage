-- AL-JULAIDY starter schema.
-- Review and test all policies with a qualified developer before production.
create extension if not exists pgcrypto;

create table if not exists public.member_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  age integer not null check (age >= 18),
  gender text not null check (gender in ('man','woman')),
  country text not null,
  bio text,
  marriage_intention text,
  wali_opt_in boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.member_profiles enable row level security;

-- Members can create and edit only their own profile.
create policy "members insert own profile"
on public.member_profiles for insert
to authenticated
with check (auth.uid() = id);

create policy "members update own profile"
on public.member_profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

create policy "members read own profile"
on public.member_profiles for select
to authenticated
using (auth.uid() = id);

create table if not exists public.wali_invitations (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references auth.users(id) on delete cascade,
  wali_email text not null,
  status text not null default 'pending'
    check (status in ('pending','accepted','declined','revoked')),
  created_at timestamptz not null default now()
);

alter table public.wali_invitations enable row level security;

create policy "member manages own wali invitations"
on public.wali_invitations for all
to authenticated
using (auth.uid() = member_id)
with check (auth.uid() = member_id);

-- IMPORTANT:
-- This deliberately does not expose identity documents or verification data.
-- Add a private storage bucket and provider-backed verification workflow.
-- Add reviewed policies for mutual interests, conversations, messages,
-- reports, blocks, subscriptions and admin moderation before launch.
